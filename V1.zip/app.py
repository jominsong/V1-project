from flask import Flask, render_template, request, jsonify, send_from_directory
from coupang_scraper import get_coupang_reviews
from gmarket_scraper import get_gmarket_reviews
from review_analyzer import analyze_reviews_in_one_call
from ai_detector import filter_reviews_by_ai
import threading
import webbrowser
import time

app = Flask(__name__, template_folder="page", static_folder="etc")

# API 키를 상수로 정의
OPENAI_API_KEY = "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"
SAPLING_API_KEY = "5U4NPLDNVSILLYMX966X7CSKN3DQJTCT"

def open_browser():
    """브라우저를 자동으로 열어주는 함수"""
    time.sleep(1.5)
    webbrowser.open('http://127.0.0.1:5000/')

@app.route("/")
def index():
    """메인 URL 입력 페이지를 보여줍니다."""
    return render_template("index.html")

@app.route("/analyze", methods=['POST'])
def analyze():
    """크롤링 및 분석을 수행하고 결과를 JSON으로 반환합니다."""
    data = request.get_json()
    url = data.get("url")

    if not url:
        return jsonify({"error": "URL이 필요합니다."}), 400

    raw_reviews = []
    try:
        if "gmarket.co.kr" in url:
            raw_reviews = get_gmarket_reviews(url)
        elif "coupang.com" in url:
            print("쿠팡 URL 감지됨, 리뷰 수집 시작...")
            raw_reviews = get_coupang_reviews(url, max_pages=3)
            print(f"쿠팡에서 {len(raw_reviews)}개의 리뷰를 수집했습니다.")
        else:
            return jsonify({"error": "지원하지 않는 URL입니다. 지마켓 또는 쿠팡 URL을 입력해주세요."}), 400

        if not raw_reviews:
            return jsonify({"error": "리뷰를 가져오지 못했습니다. URL을 다시 확인해주세요."}), 500

        print(f"수집된 리뷰 수: {len(raw_reviews)}")
        human_reviews = filter_reviews_by_ai(raw_reviews, SAPLING_API_KEY)
        filter_info = f"총 {len(raw_reviews)}개의 리뷰 중 AI 의심 리뷰 {len(raw_reviews) - len(human_reviews)}개를 제외하고 분석했습니다."

        if not human_reviews:
            return jsonify({"summary": "분석할 수 있는 사용자 리뷰가 없습니다.", "filter_info": filter_info})

        analysis_result = analyze_reviews_in_one_call(human_reviews, OPENAI_API_KEY)
        analysis_result['filter_info'] = filter_info
        analysis_result['reviews'] = human_reviews

        return jsonify(analysis_result)
    except Exception as e:
        print(f"분석 중 오류 발생: {str(e)}")
        return jsonify({"error": f"분석 중 오류가 발생했습니다: {str(e)}"}), 500

@app.route("/result")
def result():
    """결과 데이터를 받아 result.html 페이지를 렌더링합니다."""
    return render_template("result.html")

@app.route("/sitechoose")
def sitechoose():
    return render_template("sitechoose.html")

@app.route("/url")
def url_page():
    return render_template("url.html")

@app.route("/loding")
def loding():
    return render_template("loding.html")

@app.route('/etc/<path:filename>')
def serve_etc(filename):
    return send_from_directory('etc', filename)

@app.route('/img/<path:filename>')
def serve_img(filename):
    return send_from_directory('img', filename)

@app.route('/page/<path:filename>')
def serve_page(filename):
    return send_from_directory('page', filename)

if __name__ == "__main__":
    # 브라우저를 자동으로 여는 스레드 시작
    threading.Thread(target=open_browser).start()
    # Flask 서버 실행
    app.run(debug=False)