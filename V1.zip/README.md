pip install -r requirements.txt
set FLASK_APP=app.py
flask run