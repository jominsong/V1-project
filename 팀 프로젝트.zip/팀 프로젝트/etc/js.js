//---- (index 관련) ----//
function goNext() {
    window.location.href = "sitechoose.html";
}

//---- (sitechoose 관련) ----//
let selectedSite = null;
function selectSite(card) {
    document.querySelectorAll('.site-card').forEach(c => c.classList.remove('selected'));
    card.classList.add('selected');
    selectedSite = card.getAttribute("data-site");
}
function goContinue() {
    if (!selectedSite) {
        alert("사이트를 선택하세요!");
        return;
    }
    window.location.href = `url.html?site=${selectedSite}`;
}

//---- (url 관련) ----//
function goLoading() {
    const url = document.getElementById("product_url").value.trim();
    if(!url) {
        alert("상품 URL을 입력하세요!");
        return;
    }
    // site 파라미터가 있을 경우 같이 넘기기
    const params = new URLSearchParams(window.location.search);
    const site = params.get("site");
    // site, url 모두 loding.html에 전달해줍니다!
    window.location.href = `loding.html?site=${site}&url=${encodeURIComponent(url)}`;
}


//---- (loding 관련) ----//
const bar = document.getElementById('bar');
const text = document.getElementById('percent');
if (bar && text) { // loding.html에서만 동작!
    let percent = 0;
    let interval = setInterval(function() {
        percent += Math.floor(Math.random() * 7 + 4);
        if(percent >= 100) {
            percent = 100;
            clearInterval(interval);
            setTimeout(function() {
                window.location.href = 'result.html';
            }, 900);
        }
        bar.style.width = percent + "%";
        text.textContent = percent + "%";
    }, 400);
}



