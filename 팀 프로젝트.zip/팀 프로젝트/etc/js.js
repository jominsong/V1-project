//---- (index 관련) ----//
function goNext() {
    window.location.href = "/sitechoose";
}

//---- (sitechoose 관련) ----//
let selectedSite = null;
function selectSite(card) {
    document.querySelectorAll('.site-card').forEach(c => c.classList.remove('selected'));
    card.classList.add('selected');
    selectedSite = card.getAttribute("data-site");
}
function goContinue() {
    if (!selectedSite) {
        alert("사이트를 선택하세요!");
        return;
    }
    window.location.href = `/url?site=${selectedSite}`;
}

//---- (url 관련) ----//
function goLoading() {
    const url = document.getElementById("product_url").value.trim();
    if(!url) {
        alert("상품 URL을 입력하세요!");
        return;
    }
    const params = new URLSearchParams(window.location.search);
    const site = params.get("site");
    window.location.href = `/loding?site=${site}&url=${encodeURIComponent(url)}`;
}

//---- (loding 관련) ----//
const bar = document.getElementById('bar');
const text = document.getElementById('percent');

async function startAnalysisAndMove() {
    const params = new URLSearchParams(window.location.search);
    const url = params.get("url");
    if (!url) return;

    let percent = 0;
    let interval = setInterval(function() {
        percent += Math.floor(Math.random() * 7 + 4);
        if(percent > 95) percent = 95;
        bar.style.width = percent + "%";
        text.textContent = percent + "%";
    }, 400);

    try {
        const response = await fetch("/analyze", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ url })
        });
        const data = await response.json();
        clearInterval(interval);
        bar.style.width = "100%";
        text.textContent = "100%";
        // 분석 결과를 localStorage에 저장
        localStorage.setItem("analyze_result", JSON.stringify(data));
        setTimeout(function() {
            window.location.href = `/result?url=${encodeURIComponent(url)}`;
        }, 700);
    } catch (e) {
        clearInterval(interval);
        alert("분석 중 오류가 발생했습니다.");
        console.error(e);
    }
}

if (bar && text) {
    startAnalysisAndMove();
}

//---- (result 관련) ----//
window.onload = function() {
    if (!document.getElementById('trust-score-value')) return;

    const data = JSON.parse(localStorage.getItem("analyze_result") || "{}");

    if (!data.reviews || data.reviews.length === 0) {
        alert("리뷰를 불러오지 못했습니다. 상품 URL을 다시 확인해 주세요.");
        return;
    }

    // 신뢰도 점수 (%), 색상 동적 적용
    const score = data.trust_score?.score ? parseInt(data.trust_score.score) : 0;
    document.getElementById('trust-score-value').innerText = score;
    const circle = document.getElementById('trust-score-circle');
    const percent_span = document.querySelector('.trust-score-percent'); // % 스팬 선택

    circle.classList.remove('trust-red', 'trust-green', 'trust-blue');
    if(score >= 85) {
        circle.classList.add('trust-blue');
    } else if(score >= 60) {
        circle.classList.add('trust-green');
    } else {
        circle.classList.add('trust-red');
    }
    // % 기호도 같은 색상 적용
    percent_span.style.color = window.getComputedStyle(circle).color;


    document.getElementById('trust-reason').innerText = data.trust_score?.reason || "";
    document.getElementById('summary').innerText = data.summary || "";

    if (data.sentiment) {
        const positive = parseInt(data.sentiment.positive_count) || 0;
        const negative = parseInt(data.sentiment.negative_count) || 0;
        const neutral = parseInt(data.sentiment.neutral_count) || 0;
        document.getElementById('positive-count').innerText = positive;
        document.getElementById('neutral-count').innerText = neutral; // 순서 변경
        document.getElementById('negative-count').innerText = negative; // 순서 변경

        const ctx = document.getElementById('sentimentChart').getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['긍정', '부정', '종합적'],
                datasets: [{
                    data: [positive, negative, neutral],
                    backgroundColor: ['#4caf50', '#e74c3c', '#f1c40f'],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: false,
                cutout: '70%',
                plugins: {
                    legend: { display: true, position: 'right' }
                }
            }
        });
    }

    document.getElementById('filter-info').innerText = data.filter_info || "";
    const reviewList = document.getElementById('review-list');
    reviewList.innerHTML = "";
    (data.reviews || []).forEach(review => {
        const div = document.createElement('div');
        div.className = "review-item";
        div.innerText = review;
        reviewList.appendChild(div);
    });
};