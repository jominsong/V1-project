import requests
import json
import time
import random

def get_coupang_reviews(url, max_pages=3, timeout=20):
    try:
        # URL에서 상품 ID 추출
        product_id = url.split('products/')[-1].split('?')[0]
        print(f"상품 ID: {product_id}")

        all_reviews = []
        page = 1

        while page <= max_pages:
            print(f"--- {page} 페이지 리뷰 수집 시작 ---")
            
            # API URL 구성
            api_url = f"https://www.coupang.com/vp/product/reviews?productId={product_id}&page={page}&size=20&sortBy=ORDER_SCORE_ASC&ratings=&q=&viRoleCode=3&ratingSummary=true"
            
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
                "Accept": "application/json, text/plain, */*",
                "Accept-Language": "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7",
                "Referer": url,
                "Origin": "https://www.coupang.com",
                "Connection": "keep-alive"
            }

            try:
                print(f"API 요청 시도: {api_url}")
                response = requests.get(api_url, headers=headers, timeout=timeout)
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if 'data' in data and 'reviews' in data['data']:
                        reviews = data['data']['reviews']
                        
                        if not reviews:
                            print("더 이상 리뷰가 없습니다.")
                            break
                            
                        for review in reviews:
                            if 'content' in review:
                                content = review['content'].strip()
                                if content:
                                    all_reviews.append(content)
                                    print(f"리뷰 추가됨: {content[:50]}...")
                        
                        print(f"{page} 페이지에서 {len(reviews)}개의 리뷰를 확인했습니다.")
                    else:
                        print("리뷰 데이터를 찾을 수 없습니다.")
                        break
                else:
                    print(f"API 요청 실패: {response.status_code}")
                    break

                # 다음 페이지로 이동
                page += 1
                time.sleep(random.uniform(1, 2))  # 랜덤 대기 시간

            except requests.exceptions.RequestException as e:
                print(f"API 요청 중 오류 발생: {e}")
                break
            except json.JSONDecodeError:
                print("JSON 파싱 오류")
                break

        print(f"총 {len(all_reviews)}개의 리뷰를 수집했습니다.")
        return all_reviews

    except Exception as e:
        print(f"크롤링 프로세스 중 심각한 에러 발생: {e}")
        return []